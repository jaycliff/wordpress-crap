<?php
    $list_of_cron_schedules = wp_get_schedules();
	if ($_POST['sdfnes_hidden'] === 'Y') {
		// Form data sent
?>
<div class="updated">
	<p><strong><?php _e('Options saved.'); ?></strong></p>
</div>
<?php
		$sdfnes_options = get_option('sdfnes_options');
		$email_title = trim($_POST['sdfnes_email_title']);
		$sender_name = trim($_POST['sdfnes_sender_name']);
		$sender_email = trim($_POST['sdfnes_sender_email']);
		$activate = trim($_POST['sdfnes_activate']);
        $max_resends = (int) trim($_POST['sdfnes_max_resends']);
        $send_interval = (int) trim($_POST['sdfnes_send_interval']);
        $temp_cron_schedule = trim($_POST['sdfnes_cron_schedule']);
        
        if (!array_key_exists($temp_cron_schedule, $list_of_cron_schedules)) {
            // Use default...
            $temp_cron_schedule = $sdfnes_options['cron_schedule'];
        }
        
		$sdfnes_options['email_title'] = $email_title;
		//update_option('sdfnes_email_title', $email_title);
		if (!empty($sender_name)) {
			if ($sender_name === '{blogname}') {
				$sdfnes_options['sender_name'] = get_option('blogname');
				//update_option('sdfnes_sender_email', get_option('blogname'));
			} else {
				$sdfnes_options['sender_name'] = $sender_name;
				//update_option('sdfnes_sender_name', $sender_name);
			}
		} else {
			$sender_name = $sdfnes_options['sender_name'];
		}
		if (!empty($sender_email)) {
			if ($sender_email === '{admin_email}') {
				$sdfnes_options['sender_email'] = get_option('admin_email');
				//update_option('sdfnes_sender_email', get_option('admin_email'));
			} else {
				$sdfnes_options['sender_email'] = $sender_email;
				//update_option('sdfnes_sender_email', $sender_email;);
			}
		} else {
			$sender_email = $sdfnes_options['sender_email'];
		}
		if ($activate === 'true') {
			if ($sdfnes_options['activate'] !== true) {
                
                $cron_schedule = $temp_cron_schedule;
                $sdfnes_options['cron_schedule'] = $temp_cron_schedule;
                
		        $start_time = strtotime('12:00 am UTC');
	            $sdfnes_options['start'] = $start_time;
	            $sdfnes_options['end'] = $start_time + 86400;
                $sdfnes_options['intialize_system_queue'] = true;
                $time = time();
                wp_schedule_event($time, 'monthly', 'sdfnes_clear_logged_lists');
				wp_schedule_event($time, $cron_schedule, 'sdfnes_main_hook');
			} else {
                $cron_schedule = $sdfnes_options['cron_schedule'];
            }
			$activate = true;
		} else {
            // Let's treat values other than 'true' as falsy.
			if ($sdfnes_options['activate'] !== false) {
                $cron_schedule = $sdfnes_options['cron_schedule'];
				// Delete all json files
		        delete_all_json_and_dat_files();
		        // Remove schedule for the main hook
		        wp_clear_scheduled_hook('sdfnes_main_hook');
			}
            $cron_schedule = $temp_cron_schedule;
            $sdfnes_options['cron_schedule'] = $temp_cron_schedule;
			$activate = false;
		}
		$sdfnes_options['activate'] = $activate;
        if (empty($max_resends) || gettype($max_resends) !== 'integer'):
?>
<div class="error">
	<p><strong><?php _e('Invalid value for "Maximum Resends". Value must be an integer.'); ?></strong></p>
</div>
<?php
			$max_resends = $sdfnes_options['max_resends'];
		endif;
        if (empty($max_resends) || gettype($max_resends) !== 'integer') {
            $max_resends = 3;
        }
        $sdfnes_options['max_resends'] = $max_resends;
        if (empty($send_interval) || gettype($send_interval) !== 'integer' || $send_interval <= 0):
?>
<div class="error">
	<p><strong><?php _e('Invalid value for "Send Interval". Value must be a non-zero unsigned (positive) integer.'); ?></strong></p>
</div>
<?php
			$send_interval = $sdfnes_options['send_interval'];
		endif;
        if (empty($send_interval) || gettype($send_interval) !== 'integer' || $send_interval <= 0) {
            $send_interval = 16667;
        }
        $sdfnes_options['send_interval'] = $send_interval;
		update_option('sdfnes_options', $sdfnes_options);
	} else {
		// Normal page display...
        $update_options = false;
		$sdfnes_options = get_option('sdfnes_options');
		$sender_name = $sdfnes_options['sender_name'];
		if ($sender_name === get_option('blogname')) {
			$sender_name = '{blogname}';
		}
		$sender_email = $sdfnes_options['sender_email'];
		if ($sender_email === get_option('admin_email')) {
			$sender_email = '{admin_email}';
		}
		$activate = $sdfnes_options['activate'];
        $cron_schedule = $sdfnes_options['cron_schedule'];
        if (empty($cron_schedule) || gettype($cron_schedule) !== 'string') {
			$cron_schedule = 'everyminute';
            $sdfnes_options['cron_schedule'] = $cron_schedule;
            $update_options = true;
        }
        $max_resends = $sdfnes_options['max_resends'];
        if (empty($max_resends) || gettype($max_resends) !== 'integer') {
			$max_resends = 3;
            $sdfnes_options['max_resends'] = $max_resends;
            $update_options = true;
        }
        $send_interval = $sdfnes_options['send_interval'];
        if (empty($send_interval) || gettype($send_interval) !== 'integer') {
			$send_interval = 16667; // (1000ms / 60sps) * 1000)
            $sdfnes_options['send_interval'] = $send_interval;
            $update_options = true;
        }
        if ($update_options) {
            update_option('sdfnes_options', $sdfnes_options);
        }
	}
?>
<?php
	if ($activate):
?>
<div class="notice">
	<p><strong><?php _e('The email queue is currently'); ?> <span style="color: #7ad03a; text-decoration: underline;"><?php _e('active'); ?></span>.</strong></p>
</div>
<?php endif; ?>
<?php if (ini_get('safe_mode')): ?>
<div class="notice">
	<p><strong><?php _e('PHP is running in safe mode. This plugin may not work properly.'); ?></strong></p>
</div>
<?php endif; ?>
<div class="notice">
	<p><strong><?php _e('Don\'t forget to add this cron in your server:'); ?></strong> <code>* * * * * wget <?php echo site_url(); ?>/wp-cron.php?doing_wp_cron=1 > /dev/null 2>&1</code></p>
</div>
<div class="wrap">
    <?php echo "<h2>" . __('Scheduled Daily Feed Notification Email Sender Settings', 'sdfnes_domain') . "</h2>"; ?>
    <form name="sdfnes_form" method="post" action="<?php echo str_replace( '%7E', '~', $_SERVER['REQUEST_URI']); ?>">
    	<input type="hidden" name="sdfnes_hidden" value="Y" />
    	<?php echo "<h3>" . __('Basic Options', 'sdfnes_domain') . "</h3>"; ?>
		<table class="form-table">
			<tr>
				<th style="width: 150px;"><label for="sdfnes_email_title"><?php _e("Email Title:" ); ?></label></th>
				<td><input style="width: 100%;" type="text" id="sdfnes_email_title" name="sdfnes_email_title" value="<?php echo $sdfnes_options['email_title']; ?>" placeholder="Enter email title" size="20" /></td>
				<td><span style="font-style: italic; margin-left: 1em; color: #a0a0a0;"><?php _e("example"); ?>: <code><?php _e("Your Daily Email Notification"); ?></code></span></td>
			</tr>
			<tr>
				<th style="width: 150px;"><label for="sdfnes_sender_name"><?php _e("Sender Name:" ); ?></label></th>
				<td><input style="width: 100%;" type="text" id="sdfnes_sender_name" name="sdfnes_sender_name" value="<?php echo $sender_name; ?>" placeholder="Enter sender name" size="20" /></td>
				<td><span style="font-style: italic; margin-left: 1em; color: #a0a0a0;"><?php _e("example"); ?>: <code><?php _e("My Cool Website"); ?></code> or <code>{blogname}</code></span></td>
			</tr>
			<tr>
				<th style="width: 150px;"><label for="sdfnes_sender_email"><?php _e("Sender Email:" ); ?></label></th>
				<td><input style="width: 100%;" type="text" id="sdfnes_sender_email" name="sdfnes_sender_email" value="<?php echo $sender_email; ?>" placeholder="Enter sender email" size="20" /></td>
				<td><span style="font-style: italic; margin-left: 1em; color: #a0a0a0;"><?php _e("example"); ?>: <code>admin@yoursite.com</code> or <code>{admin_email}</code></span></td>
			</tr>
			<tr>
				<th style="width: 150px;"><label><?php _e("Start email sending:" ); ?></label></th>
				<td>
					<input style="margin-top: 0;" type="radio" <?php if ($activate === true): ?>checked="checked"<?php endif; ?> id="sdfnes_activate_yes" name="sdfnes_activate" value="true" /> <label for="sdfnes_activate_yes">Yes</label>
					&nbsp;
					<input style="margin-top: 0;" type="radio" <?php if ($activate === false): ?>checked="checked"<?php endif; ?> id="sdfnes_activate_no" name="sdfnes_activate" value="false" /> <label for="sdfnes_activate_no">No</label>
				</td>
				<td><span style="font-style: italic; margin-left: 1em; color: #a0a0a0;"><?php _e("Start / stop the email queue"); ?></span></td>
			</tr>
        </table>
    	<?php echo "<h3>" . __('Advanced Options', 'sdfnes_domain') . "</h3>"; ?>
        <table class="form-table">
			<tr>
				<th style="width: 150px;"><label for="sdfnes_cron_schedule"><?php _e("Cron Schedule:" ); ?></label></th>
				<td>
                    <select <?php if ($activate) { echo 'disabled="disabled" '; } ?>style="width: 100%;" id="sdfnes_cron_schedule" name="sdfnes_cron_schedule" value="<?php echo $cron_schedule; ?>" placeholder="Select Cron Schedule">
                        <?php foreach ($list_of_cron_schedules as $cron_schedule_key => $cron_data): if ($cron_data['interval'] <= 3600): ?>
                        <option <?php if ($cron_schedule === $cron_schedule_key) { echo 'selected="selected" '; } ?>value="<?php echo $cron_schedule_key; ?>"><?php echo $cron_data['display']; ?></option>
                        <?php endif; endforeach; ?>
                    </select>
                </td>
				<td><span style="font-style: italic; margin-left: 1em; color: #a0a0a0;"><?php _e("example"); ?>: <code>Every minute</code></span></td>
			</tr>
			<tr>
				<th style="width: 150px;"><label for="sdfnes_max_resends"><?php _e("Maximum Resends:" ); ?></label></th>
				<td><input style="width: 100%;" type="text" id="sdfnes_max_resends" name="sdfnes_max_resends" value="<?php echo $max_resends; ?>" placeholder="Enter the maximum number of resends" size="20" /></td>
				<td><span style="font-style: italic; margin-left: 1em; color: #a0a0a0;"><?php _e("example"); ?>: <code>10</code></span></td>
			</tr>
			<tr>
				<th style="width: 150px;"><label for="sdfnes_send_interval"><?php _e("Send Interval:" ); ?></label></th>
				<td><input style="width: 100%;" type="text" id="sdfnes_send_interval" name="sdfnes_send_interval" value="<?php echo $send_interval; ?>" placeholder="Enter the interval per email send (measured in microseconds)." size="20" /></td>
				<td><span style="font-style: italic; margin-left: 1em; color: #a0a0a0;"><?php _e("example"); ?>: <code>16667</code></span></td>
			</tr>
		</table>
    	<p class="submit">
    		<input class="button button-primary" type="submit" name="Submit" value="<?php _e('Update Options', 'sdfnes_domain' ) ?>" />
    	</p>
		<p id="notice-from-the-programmer" style="color: #f1f1f1;">Pardon me for the apparent lack of PHP 'brilliance' but I am a professional JavaScripter, not a PHPtard.</p>
    </form>
</div>