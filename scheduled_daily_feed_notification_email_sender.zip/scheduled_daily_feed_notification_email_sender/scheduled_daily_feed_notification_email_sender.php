<?php
    /**
        Plugin Name: Scheduled Daily Feed Notification Email Sender
        Plugin URI: http://vouchercruncher.co.uk/
        Description: Sends a daily feed notification to subscribers.
        Version: 0.2.3
        Author: Jaycliff Arcilla
        Author URI: https://github.com/jaycliff
    **/
    /**
        Pardon me for the apparent lack of PHP 'brilliance' but I am a professional JavaScripter, not a PHPtard.

        NOTES:
            See includes/category-feeds-settings.php for a portion of the feed code
            <CRON> * * * * * wget http://vouchercruncher.co.uk/wp-cron.php?doing_wp_cron=1 > /dev/null 2>&1
    **/
    require plugin_dir_path(__FILE__) . 'phpQuery-onefile.php'; // https://code.google.com/p/phpquery/wiki/Basics
    add_filter('cron_schedules', 'cron_add_everyminute');
    function cron_add_everyminute($schedules) {
        $schedules['everyminute'] = array(
            'interval' => 60,
            'display' => __('Every minute')
        );
        $schedules['everytwominutes'] = array(
            'interval' => 120,
            'display' => __('Every two minutes')
        );
        $schedules['everythreeminutes'] = array(
            'interval' => 180,
            'display' => __('Every three minutes')
        );
        $schedules['everyfourminutes'] = array(
            'interval' => 240,
            'display' => __('Every four minutes')
        );
        $schedules['everyfiveminutes'] = array(
            'interval' => 300,
            'display' => __('Every five minutes')
        );
        $schedules['everytenminutes'] = array(
            'interval' => 600,
            'display' => __('Every ten minutes')
        );
        $schedules['every15minutes'] = array(
            'interval' => 900,
            'display' => __('Every 15 minutes')
        );
        $schedules['every20minutes'] = array(
            'interval' => 1200,
            'display' => __('Every 20 minutes')
        );
        $schedules['every30minutes'] = array(
            'interval' => 1800,
            'display' => __('Every 30 minutes')
        );
        $schedules['monthly'] = array(
            'interval' => 2592000,
            'display' => __('Monthly')
        );
        return $schedules;
    }
    if (!function_exists('file_force_contents')) {
        function file_force_contents($filename, $data, $flags = 0) {
            if (!is_dir(dirname($filename))) {
                mkdir(dirname($filename) . '/', 0777, TRUE);
            }
            return file_put_contents($filename, $data, $flags);
        }
    }
    // The activation hook is executed when the plugin is activated.
    register_activation_hook(__FILE__, 'sdfnes_activation');
    // The deactivation hook is executed when the plugin is deactivated
    register_deactivation_hook(__FILE__, 'sdfnes_deactivation');
    function delete_all_json_and_dat_files() {
        $fullPath = plugin_dir_path(__FILE__);
        array_map('unlink', glob("$fullPath*.json"));
        array_map('unlink', glob("$fullPath*.dat"));
    }
    function clear_all_logged_lists() {
        $fullPath = plugin_dir_path(__FILE__) . 'lists/';
        if (file_exists($fullPath)) {
            array_map('unlink', glob("$fullPath*.json"));
        }
    }
    add_action('sdfnes_clear_logged_lists', 'clear_all_logged_lists');
    // This function is executed when the user activates the plugin
    function sdfnes_activation() {
        // Delete all json files to start fresh
        delete_all_json_and_dat_files();
        $default_options = array(
            //"start" => $start_time,
            //"end" => $start_time + 86400,
            "activate" => false,
            "email_title" => 'Your Daily Email Notification',
            "cron_schedule" => 'everyminute',
            "max_resends" => 3,
            "send_interval" => 16667, // (1000ms / 60sps) * 1000)
            "sender_name" => get_option('blogname'),
            "sender_email" => get_option('admin_email')
        );
        $sdfnes_options = get_option('sdfnes_options');
        if (empty($sdfnes_options)) {
            update_option('sdfnes_options', $default_options);
        } else {
            $sdfnes_options += $default_options;
            update_option('sdfnes_options', $sdfnes_options);
        }
    }
    // This function is executed when the user deactivates the plugin
    function sdfnes_deactivation() {
        $sdfnes_options = get_option('sdfnes_options');
        if ($sdfnes_options['activate'] === true) {
            // Delete all json files
            delete_all_json_and_dat_files();
            wp_clear_scheduled_hook('sdfnes_clear_logged_lists');
            // Remove schedule for the main hook
            wp_clear_scheduled_hook('sdfnes_main_hook');
        }
        $sdfnes_options['activate'] = false;
        update_option('sdfnes_options', $sdfnes_options);
        remove_action('sdfnes_main_hook', 'sdfnes_main_hook_handler');
    }
    // We add a function of our own to the sdfnes_main_hook action.
    add_action('sdfnes_main_hook', 'sdfnes_main_hook_handler');
    // This is the function that is executed by the hourly recurring action sdfnes_main_hook.
    // Let's work on the premise that this function will run for as long as necessary (in a separate thread), because sending emails are slooow.
    function sdfnes_main_hook_handler() {
        set_time_limit(0);
        ini_set('memory_limit', '1024M');
        $prepare_the_queue = false;
        $update_the_options = false;
        //$log_path = plugin_dir_path(__FILE__) . 'meta.json';
        $los_temp_path = plugin_dir_path(__FILE__) . 'los_temp.json';
        $template_path = plugin_dir_path(__FILE__) . 'template.dat';
        $sdfnes_options = get_option('sdfnes_options');
        $start_time = $sdfnes_options['start'];
        $end_time = $sdfnes_options['end'];
        //$current_time = time();
        $current_time = strtotime('now UTC');
        $time_now_formatted = date("g:i a");
        $current_hours = (int) (($current_time - $start_time) / 3600);
        if ($current_hours >= 24) {
            $sdfnes_options['start'] = $end_time;
            $sdfnes_options['end'] = $end_time + 86400;
            $sdfnes_options['can_send'] = false;
            $prepare_the_queue = true;
            $update_the_options = true;
        }
        // If the queue has been recently activated by the user, initialize it.
        if ($sdfnes_options['intialize_system_queue']) {
            $sdfnes_options['intialize_system_queue'] = false;
            $sdfnes_options['can_send'] = false;
            $prepare_the_queue = true;
            $update_the_options = true;
        }
        // If sending is active and yet either of these two files are missing...
        if ($sdfnes_options['can_send'] && (!file_exists($los_temp_path) || !file_exists($template_path))) {
            $prepare_the_queue = true;
            $sdfnes_options['can_send'] = false;
            $update_the_options = true;
        }
        if ($update_the_options) {
            update_option('sdfnes_options', $sdfnes_options);
        }
        if ($prepare_the_queue) {
            // Always set the list of subscribers first, because fetching the template takes a lot of time.
            $users = get_users(array(
                //'meta_key' => 'DailyEmail'
            ));
            //$users = get_users(array());
            $list_of_subscribers = array();
            // This is for sanitizing the user metadata.
            function array_map_callback($a) {
                return $a[0];
            }
            foreach ($users as $user) {
                $all_user_meta = array_map('array_map_callback', get_user_meta($user->data->ID));
                //$turn_off_email_notification = get_user_meta($user->data->ID, 'turn_off_email_notification', true);
                $turn_off_email_notification = $all_user_meta['turn_off_email_notification'];
                if (empty($turn_off_email_notification)) {
                    update_user_meta($user->data->ID, 'turn_off_email_notification', 'never');
                    $turn_off_email_notification = 'never';
                }
                if ($turn_off_email_notification === 'never') {
                    // 'time_zone' values follow this format "+8 Asia/Manila". See the form called "Time Zone" (ID: 10).
                    $timezone = $all_user_meta['time_zone'];
                    if (empty($timezone)) {
                        $timezone = 'UTC';
                    } else {
                        $timezone = explode(" ", $timezone);
                        $timezone = str_replace(' ', '_', $timezone[1]);
                    }
                    // 'preferred_time' values are whole numbers and in 24-hour format. See the form called "Preferred Time to Receive Email" (ID: 12).
                    $time_to_send = $all_user_meta['preferred_time'];
                    if (empty($time_to_send)) {
                        $time_to_send = '08:00 am';
                    } else {
                        $time_to_send .= ':00';
                        $time_to_send = date("g:i a", strtotime($time_to_send));
                    }
                    //*
                    // This is for debugging purposes, obviously.
                    if ($user->data->user_email === 'jaycliff@imumarketing.com') {
                        $time_to_send = '11:10 am';
                        $timezone = 'Asia/Manila';
                    }
                    //*/
                    $timestamp = strtotime($time_to_send . ' ' . $timezone);
                    $schedule = '';
                    // Let's add some queue descriptors. Descriptors are relative to the current time (UTC)
                    if ($timestamp <= $current_time) {
                        if ($current_time - $timestamp <= 60) {
                            // If the difference is equal or less than a minute, execute immediately!
                            $schedule = 'immediately';
                        } else {
                            // Else, schedule for later* (we're adding 24 hours (86400 seconds) to the timestamp so it can be sent later). The asterisk denotes that this user's time zone is behind UTC.
                            //$timestamp = strtotime($time_to_send . ' ' . $timezone . ' +1 day');
                            $timestamp = $timestamp + 86400;
                            $schedule = 'later*';
                        }
                    } else {
                        // Schedule for later
                        $schedule = 'later';
                    }
                    // Get the name of the day (relative to the subscriber's timestamp)
                    $subscriber_current_day = date('l', $timestamp);
                    $preferred_days = $all_user_meta['preferred_days'];
                    if (empty($preferred_days)) {
                        $preferred_days = 'Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday';
                        update_user_meta($user->data->ID, 'preferred_days', $preferred_days);
                    }
                    // 'preferred_days' contains a comma-separated list of user-defined days to send notifs.
                    $___pos = strpos($preferred_days, $subscriber_current_day);
                    // if $___pos isn't false, the subscriber's current day is in the list, so let's queue him / her up!
                    if ($___pos !== false) {
                        $voucher_type_ids = explode(', ', $all_user_meta['voucher_types_notification']);
                        foreach ($voucher_type_ids as $index => $type) {
                            $voucher_type_ids[$index] = str_replace(array('&amp;', ' ', '&'), array('and', '-', 'and'), '#' . strtolower($type));
                        }
                        $list_of_subscribers[] = array(
                            'first_name' => $all_user_meta['first_name'],
                            'user_email' => $user->data->user_email,
                            'user_login' => $user->data->user_login,
                            'user_id' => $user->data->ID,
                            'timezone' => $timezone,
                            'time_to_send' => $time_to_send,
                            'timestamp' => $timestamp,
                            'subscriber_current_day' => $subscriber_current_day,
                            'preferred_days' => $preferred_days,
                            'voucher_type_ids' => implode(', ', $voucher_type_ids),
                            //'time_now' => $current_time,
                            'schedule' => $schedule
                        );
                    }
                } else {
                    if ($turn_off_email_notification !== 'permanent') {
                        $time_remaining = $all_user_meta['resume_email_notification_countdown'];
                        if ($time_remaining !== '') {
                            $time_remaining = strtotime($turn_off_email_notification);
                            update_user_meta($user->data->ID, 'resume_email_notification_countdown', $time_remaining);
                        } else {
                            $time_remaining = (int) $time_remaining;
                            if ($time_remaining - $current_time <= 0) {
                                delete_user_meta($user->data->ID, 'resume_email_notification_countdown');
                                update_user_meta($user->data->ID, 'turn_off_email_notification', 'never');
                            }
                        }
                    }
                }
            }
            $json_of_subscribers = json_encode($list_of_subscribers);
            file_put_contents($los_temp_path, $json_of_subscribers);
            file_force_contents(plugin_dir_path(__FILE__) . 'lists/subscriber-list-' . date('Y-m-d') . '.json', $json_of_subscribers);
            
            // START GENERATING FULL VOUCHER TYPES CONTENT TEMPLATE
            include_once('feeds_fetcher.php'); // $all_feeds_data (Needs refactoring because it's sooo slooow!!!)
            $template = str_ireplace('%%feed-contents%%', $all_feeds_data, file_get_contents(ABSPATH . '/mailer/feeder.html'));
            file_put_contents($template_path, $template);
            // END GENERATING FULL VOUCHER TYPES CONTENT TEMPLATE
            
            //file_force_contents(plugin_dir_path(__FILE__) . 'logs/MESSAGE-' . date('Y-m-d') . '.txt', 'Everything looks fine...' . "\n", FILE_APPEND | LOCK_EX);
            
            // Re-enable sending
            $sdfnes_options['can_send'] = true;
            update_option('sdfnes_options', $sdfnes_options);
        }
        if ($sdfnes_options['can_send']) {
            /**
                Okay, this is it! Do the actual sending of the emails here.
            **/
            if (empty($template)) {
                $template = file_get_contents($template_path);
            }
            $queue_list = array();
            if (empty($list_of_subscribers)) {
                $list_of_subscribers = json_decode(file_get_contents($los_temp_path), true);
            }
            $number_of_subscribers = count($list_of_subscribers);
            foreach ($list_of_subscribers as $index => $subscriber) {
                // If time has passed, queue it!
                if ($subscriber['timestamp'] <= $current_time) {
                    unset($list_of_subscribers[$index]);
                    $queue_list[] = $subscriber;
                }
            }
            if (count($queue_list) > 0) {
                // If the $queue_list contains items, that would mean some items were removed from $list_of_subscribers (HINT: The code above), so an update is necessary.
                file_put_contents($los_temp_path, json_encode(array_values($list_of_subscribers)));
            } else {
                // ...else, nothing has been added to the queue, so let's bail out!
                return;
            }
            $sent_log_string = '----- START BATCH [' . $time_now_formatted . '] -----' . PHP_EOL;
            $failed_log_string = '----- START BATCH [' . $time_now_formatted . '] -----' . PHP_EOL;
            $email_title = $sdfnes_options['email_title'];
            $headers = array(
                'Content-Type: text/html; charset=UTF-8',
                'From: ' . $sdfnes_options['sender_name'] . ' <' . $sdfnes_options['sender_email'] . '>'
            );
            $number_of_sent_emails = 0;
            $number_of_failed_sends = 0;
            //$delay_timeout = 0;
            $requeue_list = array();
            $resend_max = (int) $sdfnes_options['max_resends']; // Just in case something unusual happens, always cast to integer.
            $send_interval = $sdfnes_options['send_interval']; // for usleep in-between sends
            // Some failed sends will get requeued once, hence the while-check.
            while (count($queue_list) > 0) {
                foreach ($queue_list as $index => $subscriber) {
                    //unset($queue_list[$index]);
                    $subscriber_first_name = $subscriber['first_name'];
                    $subscriber_email = $subscriber['user_email'];
                    $subscriber_id = $subscriber['user_id'];
                    $subscriber_login = $subscriber['user_login'];
                    $message = str_ireplace(array(
                        '%%first-name%%',
                        '%%user-preferences-express-url%%'
                    ), array(
                        $subscriber_first_name,
                        site_url('/dashboard/?dl=1&ui=' . $subscriber_id . '&un=' . $subscriber_login)
                    ), $template);
                    if (!empty($subscriber['voucher_type_ids'])) {
                        // http://stackoverflow.com/questions/2469222/how-to-convert-object-into-string-in-php
                        $filtered_template = phpQuery::newDocumentHTML($message);
                        $filtered_template->find('div.page-content-feeds')->not($subscriber['voucher_type_ids'])->remove();
                        $message = (string) $filtered_template;
                    }
                    if (wp_mail($subscriber_email, $email_title, $message, $headers)) {
                        unset($queue_list[$index]);
                        $number_of_sent_emails += 1;
                        $sent_log_string .= 'NAME: ' . $subscriber_first_name . ', EMAIL: ' . $subscriber_email . ', ID: ' . $subscriber_id . ', TIME SENT: ' . date("F j, Y, g:i a") . PHP_EOL;
                    } else {
                        if (isset($requeue_list[$subscriber_email])) {
                            if ($requeue_list[$subscriber_email] === $resend_max) {
                                // If this subscriber has already reached the maximum number of resends, give up!
                                unset($queue_list[$index]);
                                $number_of_failed_sends += 1;
                                $failed_log_string .= 'NAME: ' . $subscriber_first_name . ', EMAIL: ' . $subscriber_email . ', ID: ' . $subscriber_id . ', TIME SENT: ' . date("F j, Y, g:i a") . PHP_EOL;
                            } else {
                                // ...else 'requeue' it back!
                                $requeue_list[$subscriber_email] += 1;
                            }
                        } else {
                            $requeue_list[$subscriber_email] = 1;
                        }
                    }
                    // 16.667ms sleep. Why the sleep? Because php sucks donkey balls!
                    // Actually, it's to avoid the timeout when too many wp_mail calls are made... Because php really sucks!!!
                    usleep($send_interval); // example: 16667 ~ ((1000ms / 60sps) * 1000)
                }
                /*
                    Unsetting array items will leave 'holes'.
                    
                    Example:
                        $array = array(1, 2, 3, 4, 5);
                        unset($array[2]);
                        // This will print out [[0] => 1, [1] => 2, [3] => 4, [4] => 5]. Notice the missing index '2'
                        print_r($array);
                        
                    array_values will tidy up the remaining items. 
                    
                    Example:
                        $array = array(1, 2, 3, 4, 5);
                        unset($array[2]);
                        // This will print out [[0] => 1, [1] => 2, [2] => 4, [3] => 5].
                        print_r(array_values($array));
                */
                $queue_list = array_values($queue_list);
            }
            // Let's output the logs for both success and failed sends, if there are any.
            if ($number_of_sent_emails > 0) {
                $sent_log_string .= '----- END BATCH   [' . $time_now_formatted . '] -----' . PHP_EOL;
                file_force_contents(plugin_dir_path(__FILE__) . 'logs/' . date('Y-m-d') . '-log.txt', $sent_log_string, FILE_APPEND | LOCK_EX);
            }
            if ($number_of_failed_sends > 0) {
                $failed_log_string .= '----- END BATCH   [' . $time_now_formatted . '] -----' . PHP_EOL;
                file_force_contents(plugin_dir_path(__FILE__) . 'logs/FAILED-SENDS-' . date('Y-m-d') . '-log.txt', $failed_log_string, FILE_APPEND | LOCK_EX);
            }
        }
    }
    
    /*************** Admin function ***************/
    
    if (is_admin()) {
        function sdfnes_admin() {
        	include('sdfnes_admin.php');
        }
        function sdfnes_admin_actions() {
            add_options_page("Scheduled Daily Feed Notification Email Sender Settings", "SDFNES", 1, "options_sdfnes", "sdfnes_admin");
        }
        add_action('admin_menu', 'sdfnes_admin_actions');
    }
?>
