<?php ob_start(); ?>
<?php
    
    include_once(ABSPATH . WPINC . '/feed.php');
    include_once(ABSPATH . WPINC . '/rss.php');
    
    class SDFNES_FeedsPrettyLink {
        public function generateValidSlug($num_chars = 4) {
            global $wpdb;
            
            $slug = self::gen_random_string($num_chars);
            
            $query = "SELECT slug FROM {$table_name}";
            $slugs = $wpdb->get_col($query, 0);
            
            // It is highly unlikely that we'll ever see 2 identical random slugs
            // but just in case, here's some code to prevent collisions
            while (in_array($slug, $slugs)) {
                $slug = self::gen_random_string($num_chars);
            }
            
            return $slug;
        }
        public static function gen_random_string($length = 4) {
            $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
            $string = '';
            $max_index = strlen($characters) - 1;
            
            for ($p = 0; $p < $length; $p += 1) {
                $string .= $characters[mt_rand(0, $max_index)];
            }
            
            return $string;
        }
        public function create($f_url, $f_name) {
            global $wpdb;
            
            $table_name = "{$wpdb->prefix}prli_links";
            
            $isRecorded = "SELECT url FROM {$table_name} WHERE url = '{$f_url}'";
            $wpdb->get_results($isRecorded);
            $recs = $wpdb->num_rows;
            
            if ($recs === 0) {
                $slug = self::generateValidSlug();
                
                $query_str = "INSERT INTO {$table_name} " . 
                     '(url,'.
                      'slug,'.
                      'name,'.
                      'param_forwarding,'.
                      'param_struct,'.
                      'redirect_type,'.
                      'description,'.
                      'track_me,'.
                      'nofollow,'.
                      'group_id,'.
                      'created_at) ' .
                      'VALUES (%s,%s,%s,%s,%s,%s,%s,%d,%d,%d,NOW())';
                
                $query = $wpdb->prepare(
                    $query_str,
                    $f_url,
                    $slug,
                    $f_name,
                    ' ',
                    ' ',
                    307,
                    ' ',
                    1,
                    0,
                    1
                );
                
                $query_results = $wpdb->query($query);
            }
        }
    }
    
    $taxonomies = get_terms(APP_TAX_CAT, array(
        'orderby' => 'name',
        'order'   => 'ASC'
    ));
    $feed_data = array(); // $f1, $f2, $f3, etc. and all related variables should refer to this.
    $url_temp = '';
    foreach ($taxonomies as $taxonomy) {
        $url_temp = get_term_link($taxonomy->name, APP_TAX_CAT);
        $feed_data[$taxonomy->name] = $url_temp;
        SDFNES_FeedsPrettyLink::create($url_temp, $taxonomy->name);
    }
    unset($url_temp);
    
    global $wpdb;
    $table_name = "{$wpdb->prefix}prli_links";
    
    //file_force_contents(plugin_dir_path(__FILE__) . 'feed-data.dat', json_encode($feed_data), FILE_APPEND | LOCK_EX);
    
?>
<!-- Markup below -->
        <div id="feed-wrapper" style="background-color: #ffffff; padding: 10px;">
<?php foreach ($feed_data as $feed_name => $feed_url): ?>
            <div id="<?php echo str_replace(array('&amp;', ' ', '&'), array('and', '-', 'and'), strtolower($feed_name)); ?>" class="page-content-feeds" style="width: 100%; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 1.42857143; color: #333; background-color: #ffffff;">
                <h4 style="color:#AE1111;">New Voucher Codes in <?php echo $feed_name; ?></h4>
        <?php
            $rss = fetch_feed($feed_url . 'feed/');
            $rss->enable_order_by_date(false);
            $maxitems = 0;
            if (!is_wp_error($rss)) {
                $maxitems = $rss->get_item_quantity(4);
                $rss_items = $rss->get_items(0, $maxitems);
            }
        ?>
        <?php if ($maxitems === 0): ?>
                <table id="no-items">
                    <tr>
                        <td><?php _e('No items'); ?></td>
                    </tr>
                </table>
        <?php else: 
            echo '<table style="width: 100%;">';
            $i = 0;
            $rows = 0;
            foreach ($rss_items as $item):
                $url = $item->get_permalink();
                $postid = url_to_postid($url);
                // Insert to Pretty Link
                SDFNES_FeedsPrettyLink::create($url, $item->get_title());
                
                $ch = curl_init();
                $timeout = 5;
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
                $data = curl_exec($ch);
                
                $dom = new DOMDocument();
                $res = @$dom->loadHTML($data);
                
                if (!fmod($i, 2)) {
                    echo "<tr style='margin: 0px auto;width: 100%;'>";
                    echo "<td class='col-md-6' style='width: 100%; padding: 0;'>";
                } 
                echo "<table class='tblitem' style='width: 100%;float: left;border-top: 1px solid #eaeaea;margin-bottom: 0px!important;'>";
                echo "<tr height='100px'>";
                echo "<td style='width: 25%;'>";
                
                // STORE IMAGE
                $xpath = new DomXPath($dom);
                $class = 'store-image';
                $divs = $xpath->query("//*[contains(concat(' ', normalize-space(@class), ' '), ' $class ')]");
                
                foreach ($divs as $div) {
                    $divimg = preg_replace('/<a href[^<>]+>|<\/a>/s', '', $dom->saveXML($div));
                    $img = preg_replace('/<div class[^<>]+>|<\/div>/s', ' ', $divimg);
                    $imgattr = str_replace("img", "img style='width: 100%;'", $img);
                    echo $imgattr;
                }
                
                echo "</td>";
                
                echo "<td style='width: 75%;vertical-align: middle;'>";
                echo "<div class='item-info' style='margin-left: 10px;'>";
                
                // STORE NAME
                $xpath3 = new DomXPath($dom);
                $class = 'store-info';
                $divs3 = $xpath3->query("//*[contains(concat(' ', normalize-space(@class), ' '), ' $class ')]");
                
                foreach ($divs3 as $div3) {
                    $store = preg_replace('/<a href[^<>]+>|<\/a>/s', '', $dom->saveXML($div3));
                    echo "<div style='font-size: 11px;font-weight: bold;color: black;'>".$store."</div>";
                }
                
                // COUPON TITLE
                $q = "SELECT slug FROM {$table_name} WHERE url = '{$url}'";
                $slugURL = $wpdb->get_results($q);
                foreach ($slugURL as $newSlug) {
                    $newLink = site_url()."/".$newSlug->slug;
                }
        ?>
                <a href="<?php echo $newLink; ?>" class="ctitle" style ='font-size: 12px'><?php echo esc_html($item->get_title()); ?></a>
        <?php
                // EXPIRE DATE
                $expiredate = get_post_meta($postid, 'clpr_expire_date', true);
                $newDate = date("M d, Y", strtotime($expiredate));
                
                echo "<div class='edate' style='font-size: 11px;'>Expires on ".$newDate."</div>";
                echo "</div>";
                echo "</td>";
                echo "</tr>";
                echo "</table>";
                
                curl_close($ch);
                
                if (fmod($i,2)) {
                    echo "</td>";
                    echo "</tr>";
                } 
                $i += 1;
                
            endforeach; 
            echo "</table>"; 
        ?>
        <?php endif; ?>
        <?php
            $q = "SELECT slug FROM {$table_name} WHERE url = '{$f1_url}'";
            $slugURL = $wpdb->get_results($q);
            foreach ($slugURL as $newSlug) {
                $newLink = site_url('/') . $newSlug->slug;
            }
        ?>
                <div class="more" style="font-weight: bold; text-decoration: underline; text-align: center;">
                    <a href="<?php echo $newLink;?>">Click here to see more in <?php echo $f1;?>.</a>
                </div>
                <div class="separator" style="width: 100%; height: 7px; background: linear-gradient(to right, white, black, white);margin-top: 10px;margin-bottom: 15px; "></div>
            </div>
<?php endforeach; ?>
        </div> <!-- #feed-wrapper -->
<?php
    //file_put_contents(plugin_dir_path(__FILE__) . 'all_feeds_data.dat', ob_get_contents());
    $all_feeds_data = ob_get_contents();
    ob_end_clean();
?>