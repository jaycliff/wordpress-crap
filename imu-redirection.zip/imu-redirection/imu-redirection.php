<?php
    /**
        Plugin Name: IMU Redirection
        Plugin URI: http://imumarketing.com/
        Description: Allows adding of multiple redirections of pages to target URLs based on user's location/region.
        Version: 0.1.0
        Author: Jaycliff Arcilla
        Author URI: https://github.com/jaycliff
    **/
    
    /*
        FREAKING NOTES:
            http://www.worldatlas.com/aatlas/ctycodes.htm
            http://stackoverflow.com/questions/11545661/php-force-download-json
            https://countrycode.org/
            http://stackoverflow.com/questions/3553698/php-should-i-call-exit-after-calling-location-header
            http://stackoverflow.com/questions/4100786/how-to-create-an-array-of-a-group-of-items-inside-an-html-form
            http://stackoverflow.com/questions/2407284/how-to-get-multiple-selected-values-of-select-box-in-php
            http://stackoverflow.com/questions/1995562/now-function-in-php
            http://stackoverflow.com/questions/14366928/how-to-return-just-file-name-using-glob-in-php
    */
    
    // Q: What does a vacuum cleaner and PHP have in common? A: Both suck.
    
    //delete_option('imu_redirection_options');
    /*
    $imu_redirection_plugin_options = get_option('imu_redirection_options', array(
        'regions' => array(
                'REGION 1' => array('PH', 'JP', 'CN', 'KH'),
                'REGION 2' => array('CL', 'CO', 'CG', 'AQ')
        ),
        'post_redirections' => array(
            'REGION 1' => array(
                6 => 'http://www.google.com.ph',
                12 => 'http://practiceboard.com/',
                14 => 'http://php.net/array_search'
            ),
            'REGION 2' => array(
                6 => 'http://www.yahoo.com',
                12 => 'http://practiceboard.com/',
                14 => 'http://php.net/function_exists'
            )
        )
    ));
    */
    if (!function_exists('file_force_contents')) {
        function file_force_contents($filename, $data, $flags = 0) {
            if (!is_dir(dirname($filename))) {
                mkdir(dirname($filename) . '/', 0777, TRUE);
            }
            return file_put_contents($filename, $data, $flags);
        }
    }
    $imu_redirection_plugin_options = get_option('imu_redirection_options', array('regions' => array(), 'post_redirections' => array()));
    $imu_redirection_list_of_regions = &$imu_redirection_plugin_options['regions'];
    $imu_redirection_list_of_redirects = &$imu_redirection_plugin_options['post_redirections'];
    if (!function_exists('getIPDetails')) {
        function getIPDetails($ip) {
            $url = "http://ipinfo.io/{$ip}";
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            $json = curl_exec($ch);
            curl_close($ch);
            $details = json_decode($json);
            return $details;
        }
    }
    if (!function_exists('getClientIP')) {
        function getClientIP() {
            $ipaddress = $_SERVER['REMOTE_ADDR'];
            return $ipaddress;
        }
    }
    function getRegion($country) {
        global $imu_redirection_list_of_regions;
        foreach ($imu_redirection_list_of_regions as $region_name => $region_list) {
            $search_result = array_search($country, $region_list);
            if ($search_result !== false) {
                return $region_name;
            }
        }
        return false;
    }
    function getRedirectURL($region, $page_id) {
        global $imu_redirection_list_of_redirects;
        //echo '<!-- ' . $imu_redirection_list_of_redirects[$page_id][$region] . ' -->';
        if (isset($region) && isset($imu_redirection_list_of_redirects[$region]) && isset($imu_redirection_list_of_redirects[$region][$page_id])) {
            return $imu_redirection_list_of_redirects[$region][$page_id];
        }
        return false;
    }
    function do_the_redirection() {
        global $post;
        $postID = $post->ID;
        $getIPDetails = getIPDetails(getClientIP());
        $region = getRegion($getIPDetails->country);
        $redirect_url = getRedirectURL($region, $postID);
        //echo '<!-- Region: ' . $region . ' -->';
        //echo '<!-- The post id: ' . $postID . ' -->';
        //echo '<!-- URL: ' . $redirect_url . ' -->';
        if ($redirect_url !== false) {
            if ($_SERVER['QUERY_STRING'] !== '') {
                if (strpos($redirect_url, '?') === false) {
                    header("Location: " . $redirect_url . '?' . $_SERVER['QUERY_STRING']);
                    //echo "Location: " . $redirect_url . '?' . $_SERVER['QUERY_STRING'];
                    return;
                }
                header("Location: " . $redirect_url . '&' . $_SERVER['QUERY_STRING']);
                //echo "Location: " . $redirect_url . '&' . $_SERVER['QUERY_STRING'];
                return;
            }
            header("Location: " . $redirect_url);
            return;
        }
    }
    if (!is_admin()) {
        add_action('template_redirect', 'do_the_redirection');
    } else {
        /*
        function updatePageMeta() {
            global $imu_redirection_list_of_redirects;
            foreach ($imu_redirection_list_of_redirects as $region_name => $redirection_list) {
                foreach ($redirection_list as $page_id => $target_url) {
                    //delete_post_meta($page_id, 'imur_redirection_list');
                    $meta_data = get_post_meta($page_id, 'imur_redirection_list', true);
                    if (empty($meta_data)) {
                        $meta_data = array();
                    }
                    $meta_data[$region_name] = $target_url;
                    update_post_meta($page_id, 'imur_redirection_list', $meta_data);
                }
            }
        }
        //*/
        if (!empty($_POST['imu_redirection_form_type'])) {
            switch ($_POST['imu_redirection_form_type']) {
            case 'add_region':
                if (!empty($_POST['region_name']) && !empty($_POST['region_countries'])) {
                    $imu_redirection_list_of_regions[$_POST['region_name']] = $_POST['region_countries'];
                }
                ksort($imu_redirection_list_of_regions);
                break;
            case 'update_regions':
                if (!empty($_POST['delete_region'])) {
                    unset($imu_redirection_list_of_regions[$_POST['delete_region']]);
                    if (count($imu_redirection_list_of_redirects[$_POST['delete_region']]) > 0) {
                        foreach ($imu_redirection_list_of_redirects[$_POST['delete_region']] as $page_id => $target_url) {
                            $meta_data = get_post_meta($page_id, 'imur_redirection_list', true);
                            update_post_meta($page_id, 'imur_redirection_list', $meta_data);
                            unset($meta_data[$_POST['delete_region']]);
                        }
                    }
                    unset($imu_redirection_list_of_redirects[$_POST['delete_region']]);
                } else {
                    if (!empty($_POST['regions'])) {
                        foreach ($_POST['regions'] as $region_name => $region_list) {
                            $imu_redirection_list_of_regions[$region_name] = $region_list;
                        }
                    }
                }
                //updatePageMeta();
                break;
            case 'add_redirection':
                if (!empty($_POST['redirection_region']) && !empty($_POST['redirection_page']) && !empty($_POST['redirection_url']) && filter_var($_POST['redirection_url'], FILTER_VALIDATE_URL)) {
                    if (!isset($imu_redirection_list_of_redirects[$_POST['redirection_region']])) {
                        $imu_redirection_list_of_redirects[$_POST['redirection_region']] = array();
                    }
                    $page_id = intval($_POST['redirection_page']);
                    $target_url = esc_url_raw($_POST['redirection_url']);
                    $imu_redirection_list_of_redirects[$_POST['redirection_region']][$page_id] = $target_url;
                    // Update page meta
                    $meta_data = get_post_meta($page_id, 'imur_redirection_list', true);
                    if (empty($meta_data)) {
                        $meta_data = array();
                    }
                    $meta_data[$_POST['redirection_region']] = $target_url;
                    update_post_meta($page_id, 'imur_redirection_list', $meta_data);
                    ksort($imu_redirection_list_of_redirects);
                    //updatePageMeta();
                }
                break;
            case 'update_redirections':
                if (!empty($_POST['delete_redirection'])) {
                    foreach ($_POST['delete_redirection'] as $redirection_region => $redirection_page_id) {
                        $page_id = intval($redirection_page_id);
                        unset($imu_redirection_list_of_redirects[$redirection_region][$page_id]);
                        // Update page meta
                        $meta_data = get_post_meta($page_id, 'imur_redirection_list', true);
                        unset($meta_data[$redirection_region]);
                        update_post_meta($page_id, 'imur_redirection_list', $meta_data);
                    }
                    if (count($imu_redirection_list_of_redirects[$redirection_region]) < 1) {
                        unset($imu_redirection_list_of_redirects[$redirection_region]);
                    }
                } else {
                    $imur_target_urls = $_POST['imur_target_url'];
                    foreach ($imur_target_urls as $region_name => $redirection_data) {
                        foreach ($redirection_data as $page_id => $target_url) {
                            //echo $region_name . ' => ' . $page_id . ' => ' . $target_url . PHP_EOL;
                            if (filter_var($target_url, FILTER_VALIDATE_URL)) {
                                $target_url = esc_url_raw($target_url);
                                $page_id = intval($page_id);
                                $imu_redirection_list_of_redirects[$region_name][$page_id] = $target_url;
                            }
                        }
                    }
                }
                //updatePageMeta();
                break;
            case 'import_data':
                if ($_FILES['imported_imur_json_data']['error'] === UPLOAD_ERR_OK && is_uploaded_file($_FILES['imported_imur_json_data']['tmp_name'])) {
                    file_force_contents(plugin_dir_path(__FILE__) . 'backups/IMU Redirection Settings - ' . date('F d, Y - (H-i-s)') . '.json', json_encode($imu_redirection_plugin_options), LOCK_EX);
                    $imported_region_data = json_decode(file_get_contents($_FILES['imported_imur_json_data']['tmp_name']), true);
                    $imu_redirection_list_of_regions = &$imported_region_data;
                    $imu_redirection_plugin_options['regions'] = &$imported_region_data;
                    $imu_redirection_plugin_options['post_redirections'] = array();
                    $pages = get_pages();
                    foreach ($pages as $page) {
                        delete_post_meta($page->ID, 'imur_redirection_list');
                    }
                    //$imu_redirection_list_of_redirects = &$imu_redirection_plugin_options['post_redirections'];
                }
                break;
            case 'export_data':
                header('Content-disposition: attachment; filename=imu-redirection-' . date("Y-m-d") . '.json');
                header('Content-type: application/json');
                echo json_encode($imu_redirection_plugin_options['regions']);
                exit;
                //break;
            case 'restore_backup':
                $chosen_backup = $_POST['chosen_backup'];
                if (file_exists(plugin_dir_path(__FILE__) . 'backups/' . $chosen_backup)) {
                    $imu_redirection_plugin_options = json_decode(file_get_contents(plugin_dir_path(__FILE__) . 'backups/' . $chosen_backup), true);
                    $imu_redirection_list_of_regions = &$imu_redirection_plugin_options['regions'];
                    $imu_redirection_list_of_redirects = &$imu_redirection_plugin_options['post_redirections'];
                    $pages = get_pages();
                    foreach ($pages as $page) {
                        delete_post_meta($page->ID, 'imur_redirection_list');
                    }
                    foreach ($imu_redirection_list_of_redirects as $region_name => $redirection_list) {
                        foreach ($redirection_list as $page_id => $target_url) {
                            $meta_data = get_post_meta($page_id, 'imur_redirection_list', true);
                            if (empty($meta_data)) {
                                $meta_data = array();
                            }
                            $meta_data[$region_name] = $target_url;
                            update_post_meta($page_id, 'imur_redirection_list', $meta_data);
                        }
                    }
                }
                break;
            }
            //print_r($imu_redirection_plugin_options);
            update_option('imu_redirection_options', $imu_redirection_plugin_options);
        }
        /*************** Admin function ***************/
        function imu_redirection_admin() {
        	include('imu-redirection-admin.php');
        }
        function imu_redirection_admin_actions() {
            add_options_page("IMU Redirection", "IMU Redirection", 1, "options_imu_redirection", "imu_redirection_admin");
        }
        add_action('admin_menu', 'imu_redirection_admin_actions');
        /*** STYLES ***/
        function imu_redirection_head_content() {
            echo '<style type="text/css">
                #post input[type="text"] {
                    min-height: 28px;
                }
                #imu-redirection-settings {
                    border: solid 1px #c0c0c0;
                    box-shadow: inset 0 0 5px #f8f8f8, 0 0 5px #e0e0e0;
                    margin-top: 20px;
                    padding: 10px;
                }
                #imu-redirection-settings > *:first-child {
                    margin-top: 0 !important;
                }
                #imu-redirection-settings > form {
                    background-color: #f8f8f8;
                    border: solid 1px #e0e0e0;
                    margin-top: 10px;
                    padding: 20px;
                }
                #imu-redirection-settings > form:before,
                #imu-redirection-settings > form:after {
                    clear: both;
                    content: ".";
                    display: block;
                    font-size: 0;
                    height: 0;
                    line-height: 0;
                    overflow: hidden;
                    visibility: hidden;
                }
                #imu-redirection-settings > form > h3 {
                    border-bottom: solid 1px #e0e0e0;
                    margin-bottom: 20px;
                    margin-top: 0;
                    padding-bottom: 20px;
                }
                #imu-redirection-settings > form p.submit {
                    margin-bottom: 0;
                    text-align: center;
                    padding: 10px;
                    background-color: #ececec;
                }
                #imu-redirection-settings .form-table th {
                    padding-left: 10px;
                }
                #imu-redirection-settings .form-table th:first-child {
                    padding-left: 0;
                }
                #imu-redirection-settings .specialized-table td,
                #imu-redirection-settings .specialized-table th {
                    padding: 15px 10px;
                    vertical-align: top;
                }
                #imu-redirection-settings input[type="text"],
                #imu-redirection-settings .chosen-container,
                #imu-redirection-settings .chosen-container-single {
                    max-width: 480px;
                }
                #imu-redirection-settings .chosen-container-single .chosen-single {
                    -moz-border-radius: 2px;
                    -ms-border-radius: 2px;
                    -o-border-radius: 2px;
                    -webkit-border-radius: 2px;
                    border-radius: 2px;
                }
                #imu-redirection-settings .chosen-container-multi .chosen-choices li.search-choice .search-choice-close {
                    -moz-transition: none;
                    -o-transition: none;
                    -ms-transition: none;
                    -webkit-transition: none;
                    transition: none;
                }
                #imu-redirection-settings #list-of-redirections.form-table tr > td:first-child,
                #imu-redirection-settings #list-of-redirections.form-table tr > th:first-child {
                    padding-left: 10px;
                }
                #list-of-redirections tr.region-set-a {
                    background-color: #e8e8e8;
                }
                #list-of-redirections tr.region-set-b {
                    background-color: #f0f0f0;
                }
                #imu-redirection-meta-box table tr.top-row {
                    background-color: #c0cfcf;
                }
                #imu-redirection-meta-box table tr.top-row th {
                    padding: 4px;
                }
                #imu-redirection-meta-box input.covert {
                    border-color: transparent;
                    box-shadow: none;
                }
                #imu-redirection-meta-box input.covert:focus,
                #imu-redirection-meta-box input.covert:active {
                    border-color: #5b9dd9;
                    -moz-box-shadow: 0 0 2px rgba(30, 140, 190, 0.8);
                    -ms-box-shadow: 0 0 2px rgba(30, 140, 190, 0.8);
                    -o-box-shadow: 0 0 2px rgba(30, 140, 190, 0.8);
                    -webkit-box-shadow: 0 0 2px rgba(30, 140, 190, 0.8);
                    box-shadow: 0 0 2px rgba(30, 140, 190, 0.8);
                }
            </style>';
            echo "\r\n";
            echo '<link rel="stylesheet" href="' . plugin_dir_url(__FILE__) . 'lib/chosen.css">';
            echo "\r\n";
            echo '<script src="' . plugin_dir_url(__FILE__) . 'lib/chosen.jquery.js" type="text/javascript"></script>';
        }
        add_action('admin_head', 'imu_redirection_head_content');
        // Experimental crap below
        function meta_box_show($post) {
            global $imu_redirection_list_of_regions;
            // Add a hidden nonce field for security
            wp_nonce_field('imur_page_' . $post->ID, 'imur_nonce', false);
            $meta_data = get_post_meta($post->ID, 'imur_redirection_list', true);
            if (!empty($meta_data) && count($meta_data) > 0) {
                //print_r($meta_data);
                echo '<h3 style="font-size: 14px;">List of redirections</h3>';
                echo '<table style="width: 100%;">';
                echo '<tr class="top-row"><th>Region Name</th><th>Target URL</th><th>Delete</th></tr>';
                foreach ($meta_data as $region_name => $target_url) {
                    echo '<tr>';
                    echo '<th style="text-align: left;">' . $region_name . '</th>';
                    echo '<td><input class="covert" style="min-width: 240px; width: 100%;" type="text" name="imur-redirection-target-url[' . $region_name . ']" value="' . $target_url . '" /></td>';
                    echo '<td style="text-align: center;"><input type="checkbox" name="imur-delete-redirection[]" value="' . $region_name . '" /></td>';
                    echo '</tr>';
                }
                echo '</table>';
            } else {
                echo '<p>There are no redirections for this <span title="ID: ' . $post->ID . '">page</span> yet.</p>';
            }
            if (count($imu_redirection_list_of_regions) > 0) {
                $available_regions = array();
                foreach ($imu_redirection_list_of_regions as $region_name => $redirection_list) {
                    if (!isset($meta_data[$region_name])) {
                        $available_regions[] = $region_name;
                    }
                }
                if (count($available_regions) > 0) {
                    echo '<h3 style="font-size: 14px;">Add a new redirection</h3>';
                    echo '<table>';
                    echo '<td><select style="min-width: 240px;" name="imur_region_name">';
                    echo '<option value="">Select a region</option>';
                    /*
                    foreach ($imu_redirection_list_of_regions as $region_name => $redirection_list) {
                        echo '<option value="' . $region_name . '">' . $region_name . '</option>';
                    }
                    */
                    foreach ($available_regions as $region_name):
                    ?>
                        <option value="<?php echo $region_name; ?>"><?php echo $region_name; ?></option>
                    <?php
                    endforeach;
                    echo '</select></td>';
                    echo '<td><input style="min-width: 240px;" type="text" name="imur_target_url" placeholder="Enter a target URL" /></td>';
                    echo '</tr></table>';
                }
            }
            //delete_post_meta($post->ID, 'imur_redirection_list');
            /*
            // Output the URL field
            echo '<p>';
            echo '<label for="ndg_spr_url">' . __('Mobile URL:', 'thespeedy-page-redirect') . '</label>';
            echo '<input id="ndg_spr_url" name="ndg_spr_url" type="url" value="' . esc_url($values['url_raw']) . '" size="50" style="width:80%">';
            echo '</p>';
            */
        }
        function add_the_damn_metabox() {
            add_meta_box('imu-redirection-meta-box', __('IMU Redirection', 'imu_redirection_domain'), 'meta_box_show', 'page');
        }
        add_action('add_meta_boxes', 'add_the_damn_metabox');
        function save_the_damn_post($page_id) {
            global $imu_redirection_plugin_options, $imu_redirection_list_of_redirects;
            if (!isset($_POST['imur_nonce']) || !wp_verify_nonce($_POST['imur_nonce'], 'imur_page_' . $page_id)) {
                //echo '<!-- TOTALLY NOT VALID -->';
                return;
            }
            $meta_data = get_post_meta($page_id, 'imur_redirection_list', true);
            if (empty($meta_data)) {
                $meta_data = array();
            }
            // Delete checked redirection(s)
            if (!empty($_POST['imur-delete-redirection']) && count($_POST['imur-delete-redirection']) > 0) {
                $do_update = true;
                foreach ($_POST['imur-delete-redirection'] as $region_name) {
                    unset($meta_data[$region_name]);
                    unset($imu_redirection_list_of_redirects[$region_name][$page_id]);
                }
            }
            // Change target URL
            if (!empty($_POST['imur-redirection-target-url'])) {
                foreach ($meta_data as $region_name => $target_url) {
                    if (filter_var($_POST['imur-redirection-target-url'][$region_name], FILTER_VALIDATE_URL)) {
                        $do_update = true;
                        $imu_redirection_list_of_redirects[$region_name][$page_id] = $_POST['imur-redirection-target-url'][$region_name];
                        $meta_data[$region_name] = $_POST['imur-redirection-target-url'][$region_name];
                    }
                }
            }
            // Add new redirection
            if (!empty($_POST['imur_region_name']) && !empty($_POST['imur_target_url']) && filter_var($_POST['imur_target_url'], FILTER_VALIDATE_URL)) {
                $do_update = true;
                $target_url = esc_url_raw($_POST['imur_target_url']);
                $imu_redirection_list_of_redirects[$_POST['imur_region_name']][$page_id] = $target_url;
                $meta_data[$_POST['imur_region_name']] = $target_url;
            }
            if ($do_update) {
                update_option('imu_redirection_options', $imu_redirection_plugin_options);
                update_post_meta($page_id, 'imur_redirection_list', $meta_data);
            }
        }
        add_action('save_post', 'save_the_damn_post');
    }
?>