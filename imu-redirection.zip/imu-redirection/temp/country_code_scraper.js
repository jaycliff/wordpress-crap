var country_codes = {}, textarea = document.createElement('textarea');
textarea.setAttribute('row', '100');
textarea.setAttribute('col', '100');
jQuery('table[data-sort-name="countrycode"]').eq(1).find('tr').each(function (index) {
    var $this = $(this), $cells = $this.find('td');
    if (index !== 0) {
        country_codes[$cells[0].textContent] = $cells[2].textContent.substr(0, 2);
    }
});
document.body.appendChild(textarea);
textarea.value = JSON.stringify(country_codes, null, 4);