<?php
    global $imu_redirection_list_of_regions, $imu_redirection_list_of_redirects;
    $country_code_to_region_checklist = array();
    foreach ($imu_redirection_list_of_regions as $region_name => $region_list) {
        foreach ($region_list as $country_code) {
            $country_code_to_region_checklist[$country_code] = $region_name;
        }
    }
    $imu_redirection_country_codes = json_decode(file_get_contents(plugin_dir_path(__FILE__) . 'country-codes.dat'), true);
?>
<?php echo '<h2>' . __('IMU Redirection Settings', 'imu_redirection_domain') . "</h2>"; ?>
<div id="imu-redirection-settings" class="wrap">
    <form name="imu_redirection_form" id="add-new-region" method="post" action="<?php echo str_replace('%7E', '~', $_SERVER['REQUEST_URI']); ?>">
        <input type="hidden" name="imu_redirection_form_type" value="add_region" />
    	<?php echo '<h3 style="margin-top: 0;">' . __('Create New Region', 'imu_redirection_domain') . "</h3>"; ?>
		<table class="form-table">
            <tr>
                <th style="width: 30%;">Region:</th>
                <td><input style="width: 100%;" type="text" placeholder="Enter region name" name="region_name" /></td>
            </tr>
            <tr>
                <th>Countries:</th>
                <td>
                    <select data-region="[NEW REGION]" class="chosenize" name="region_countries[]" id="imu-redirection-countries" data-placeholder="Select some countries" placeholder="Select some countries" multiple="multiple">
                        <?php foreach ($imu_redirection_country_codes as $country_name => $country_code): ?>
                            <option <?php if (array_key_exists($country_code, $country_code_to_region_checklist)) { echo 'disabled="disabled"'; } ?>value="<?php echo $country_code; ?>"><?php echo $country_name; ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>
		</table>
    	<p class="submit">
    		<input class="button button-primary" type="submit" name="add_region" value="<?php _e('Add Region', 'imu_redirection_domain' ) ?>" />
    	</p>
    </form>
    <?php if (count($imu_redirection_list_of_regions) > 0): ?>
    <form name="imu_redirection_form" method="post" action="<?php echo str_replace('%7E', '~', $_SERVER['REQUEST_URI']); ?>">
        <input type="hidden" name="imu_redirection_form_type" value="update_regions" />
        <?php echo '<h3>' . __('Edit Regions', 'imu_redirection_domain') . "</h3>"; ?>
        <table class="form-table specialized-table">
            <tr>
                <th style="width: 30%;">Region Name</th>
                <th style="width: 60%;">Countries</th>
                <th style="text-align: center;">Action</th>
            </tr>
            <?php foreach ($imu_redirection_list_of_regions as $region_name => $region_list): ?>
            <tr>
                <th><?php echo $region_name; ?></th>
                <td>
                    <select data-region="<?php echo $region_name; ?>" class="chosenize" name="regions[<?php echo $region_name; ?>][]" id="imu-redirection-countries" placeholder="Select some countries" multiple="multiple">
                        <?php foreach ($imu_redirection_country_codes as $country_name => $country_code): ?>
                            <option <?php if (array_search($country_code, $region_list) !== false) { echo 'selected="selected" '; } else if (array_key_exists($country_code, $country_code_to_region_checklist)) { echo 'disabled="disabled"'; } ?>value="<?php echo $country_code; ?>"><?php echo $country_name; ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
                <td style="text-align: center;"><button class="button" type="submit" name="delete_region" value="<?php echo $region_name; ?>">Delete</button></td>
            </tr>
            <?php endforeach; ?>
        </table>
        <p class="submit">
    		<input class="button button-primary" type="submit" name="update_regions" value="<?php _e('Update Regions', 'imu_redirection_domain' ) ?>" />
    	</p>
        <script type="text/javascript">
            jQuery(document).ready(function ($) {
                "use strict";
                $('button[name="delete_region"]').on('click', function (event) {
                    if (confirm('Are you sure you want to delete ' + this.value + '? This will also delete all associated redirections under this region.')) {
                        return;
                    }
                    event.preventDefault();
                });
            });
        </script>
    </form>
    <?php endif; ?>
    <?php if (count($imu_redirection_list_of_regions) > 0): ?>
    <form name="imu_redirection_form" id="add-new-redirection" method="post" action="<?php echo str_replace('%7E', '~', $_SERVER['REQUEST_URI']); ?>">
        <input type="hidden" name="imu_redirection_form_type" value="add_redirection" />
    	<?php echo '<h3 style="margin-top: 0;">' . __('Add New Redirection', 'imu_redirection_domain') . "</h3>"; ?>
		<table class="form-table">
            <tr>
                <th style="width: 30%;">Region:</th>
                <td>
                    <select class="chosenize" name="redirection_region" placeholder="Choose a region">
                        <?php foreach ($imu_redirection_list_of_regions as $region_name => $country_code_list): ?>
                        <option value="<?php echo $region_name; ?>"><?php echo $region_name; ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>
            <tr>
                <th>Page:</th>
                <td>
                    <select class="chosenize" name="redirection_page" placeholder="Choose a page">
                        <?php $pages = get_pages(); ?>
                        <?php foreach ($pages as $page): ?>
                            <option value="<?php echo $page->ID; ?>"><?php echo $page->post_title . '&nbsp;&nbsp;&nbsp;&lt;' . get_permalink($page->ID) . '&gt;'; ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>
            <tr>
                <th>Target URL:</th>
                <td><input style="width: 100%;" type="text" placeholder="Enter a target URL" name="redirection_url" /></td>
            </tr>
		</table>
    	<p class="submit">
    		<input class="button button-primary" type="submit" name="add_redirection" value="<?php _e('Add Redirection', 'imu_redirection_domain' ) ?>" />
    	</p>
    </form>
    <?php endif; ?>
    <?php if (count($imu_redirection_list_of_redirects) > 0): ?>
    <form name="imu_redirection_form" method="post" action="<?php echo str_replace('%7E', '~', $_SERVER['REQUEST_URI']); ?>">
        <input type="hidden" name="imu_redirection_form_type" value="update_redirections" />
        <?php echo '<h3>' . __('List of Redirections', 'imu_redirection_domain') . "</h3>"; ?>
        <div style="overflow: auto;">
            <table id="list-of-redirections" class="form-table specialized-table">
                <tr style="background-color: #c0cfcf;">
                    <th style="width: 20%;">Region Name</th>
                    <th style="width: 20%;">Page Title</th>
                    <th>Permalink</th>
                    <th>Target URL</th>
                    <th style="width: 10%; text-align: center;">Action</th>
                </tr>
                <?php
                    $tr_class = 'region-set-a';
                    foreach ($imu_redirection_list_of_redirects as $region_name => $redirection_list):
                ?>
                <?php
                    if (count($redirection_list) > 0):
                    $link_count = 0;
                    foreach ($redirection_list as $page_id => $target_url):
                ?>
                <tr class="<?php echo $tr_class; ?>">
                    <?php if ($link_count < 1): ?><th<?php if (count($redirection_list) > 0) { echo ' rowspan="' . count($redirection_list) . '"'; } ?>><?php echo $region_name; ?></th><?php endif; ?>
                    <td>
                        <?php
                            $redirection_page = get_page($page_id);
                            echo $redirection_page->post_title;
                        ?>
                    </td>
                    <td><?php echo get_permalink($page_id); ?></td>
                    <td><input style="width: 100%;" type="text" name="imur_target_url[<?php echo $region_name; ?>][<?php echo $page_id; ?>]" value="<?php echo $target_url; ?>" /></td>
                    <!-- <td><?php echo $target_url; ?></td> -->
                    <td style="text-align: center;"><button data-region-name="<?php echo $region_name; ?>" data-post-title="<?php echo $redirection_page->post_title; ?>" class="button" type="submit" name="delete_redirection[<?php echo $region_name; ?>]" value="<?php echo $page_id; ?>">Delete</button></td>
                </tr>
                <?php
                    $link_count += 1;
                    endforeach;
                ?>
                <?php
                    if ($tr_class === 'region-set-a') {
                        $tr_class = 'region-set-b';
                    } else {
                        $tr_class = 'region-set-a';
                    }
                    endif;
                    endforeach;
                ?>
            </table>
            <p class="submit">
                <input class="button button-primary" type="submit" name="update_target_urls" value="<?php _e('Update Target URL(s)', 'imu_redirection_domain' ) ?>" />
            </p>
            <script type="text/javascript">
                jQuery(document).ready(function ($) {
                    "use strict";
                    $('button[name^="delete_redirection"]').on('click', function (event) {
                        if (confirm('Are you sure you want to delete the redirection of ' + this.getAttribute('data-post-title') + ' for ' + this.getAttribute('data-region-name') + '?')) {
                            return;
                        }
                        event.preventDefault();
                    });
                });
            </script>
        </div>
    </form>
    <?php endif; ?>
    <form name="imu_redirection_form" method="post" action="<?php echo str_replace('%7E', '~', $_SERVER['REQUEST_URI']); ?>" enctype="multipart/form-data">
        <input type="hidden" name="imu_redirection_form_type" value="import_data" />
        <?php echo '<h3>' . __('Import Region Data', 'imu_redirection_domain') . "</h3>"; ?>
        <p>Import region data from exported IMU Redirection JSON file.<br /><strong style="color: red;">WARNING:</strong> Imported data will <strong>remove all existing redirections</strong> and <strong>replace all existing region data</strong>. A backup of the current settings will be created each time you import, which you can then optionally restore.</p>
        <p><input type="file" name="imported_imur_json_data" accept=".json,.js" /></p>
    	<p class="submit">
    		<input class="button button-primary" type="submit" name="import_data" value="<?php _e('Import Region Data From JSON', 'imu_redirection_domain' ) ?>" />
            <script type="text/javascript">
                jQuery(document).ready(function ($) {
                    "use strict";
                    var $file_input = $('input[name="imported_imur_json_data"]');
                    $('input[name="import_data"]').on('click', function (event) {
                        if ($file_input.val() !== '') {
                            if (confirm('Start region import?')) {
                                return;
                            }
                        } else {
                            alert('Choose an IMU Redirection region JSON file to import');
                        }
                        event.preventDefault();
                    });
                });
            </script>
    	</p>
    </form>
    <?php if (count($imu_redirection_list_of_regions) > 0): ?>
    <form name="imu_redirection_form" method="post" action="<?php echo str_replace('%7E', '~', $_SERVER['REQUEST_URI']); ?>">
        <input type="hidden" name="imu_redirection_form_type" value="export_data" />
        <?php echo '<h3>' . __('Export Region Data', 'imu_redirection_domain') . "</h3>"; ?>
        <p>Export all region data to JSON.</p>
    	<p class="submit">
    		<input class="button button-primary" type="submit" name="export_data" value="<?php _e('Export Region Data To JSON', 'imu_redirection_domain' ) ?>" />
    	</p>
    </form>
    <?php endif; ?>
    <?php
        if (is_dir(plugin_dir_path(__FILE__) . 'backups')):
            $backup_files = glob(plugin_dir_path(__FILE__) . 'backups/*.json');
            if (!empty($backup_files)):
                krsort($backup_files);
    ?>
    <form name="imu_redirection_form" method="post" action="<?php echo str_replace('%7E', '~', $_SERVER['REQUEST_URI']); ?>">
        <input type="hidden" name="imu_redirection_form_type" value="restore_backup" />
        <?php echo '<h3>' . __('Restore Backup', 'imu_redirection_domain') . "</h3>"; ?>
        <table class="form-table">
            <tr>
                <th style="width: 30%;">Choose A Backup To Restore:</th>
                <td>
                    <select class="chosenize" name="chosen_backup" placeholder="Choose a backup">
                        <?php foreach ($backup_files as $file_name): ?>
                        <option value="<?php echo basename($file_name); ?>"><?php echo basename($file_name, '.json'); ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>
        </table>
    	<p class="submit">
    		<input class="button button-primary" type="submit" name="restore_backup" value="<?php _e('Restore Now', 'imu_redirection_domain' ) ?>" />
            <script type="text/javascript">
                jQuery(document).ready(function ($) {
                    "use strict";
                    var $select = $('select[name="chosen_backup"]');
                    $('input[name="restore_backup"]').on('click', function (event) {
                        if (confirm('Are you sure you want to restore settings from [' + $select.val() + ']?')) {
                            return;
                        }
                        event.preventDefault();
                    });
                });
            </script>
    	</p>
    </form>
    <?php
            endif;
        endif;
    ?>
</div>
<p id="notice-from-the-programmer" style="color: #f1f1f1;">Pardon me for the apparent lack of PHP 'brilliance' but I am a professional JavaScripter, not a PHPtard.</p>
<script type="text/javascript">
    // Production steps of ECMA-262, Edition 5, 15.4.4.14
    // Reference: http://es5.github.io/#x15.4.4.14
    if (typeof Array.prototype.indexOf !== "function") {
        Array.prototype.indexOf = function (searchElement, fromIndex) {
            "use strict";
            var O, k, len, n;
            if (this === null || this === undefined) {
                throw new TypeError('Array.prototype.indexOf called on null or undefined');
            }
            O = Object(this);
            len = O.length >>> 0; // Converts to Uint32
            if (len === 0) {
                return -1;
            }
            // 5. If argument fromIndex was passed let n be
            //    ToInteger(fromIndex); else let n be 0.
            if (arguments.length > 1) {
                //n = Number.toInteger(fromIndex);
                // Start ToInteger conversion
                n = Number(fromIndex);
                n = (n !== n) ? 0 : (n === 0 || n === Infinity || n === -Infinity) ? n : (n > 0) ? Math.floor(n) : Math.ceil(n);
                // End ToInteger conversion
            } else {
                n = 0;
            }
            // 6. If n >= len, return -1.
            if (n >= len) {
                return -1;
            }
            // 7. If n >= 0, then Let k be n.
            // 8. Else, n<0, Let k be len - abs(n).
            //    If k is less than 0, then let k be 0.
            // k = Math.max(n >= 0 ? n : len - Math.abs(n), 0);
            k = (n >= 0) ? n : Math.max(len + n, 0);
            // 9. Repeat, while k < len
            while (k < len) {
                // a. Let Pk be ToString(k).
                //   This is implicit for LHS operands of the in operator
                // b. Let kPresent be the result of calling the
                //    HasProperty internal method of O with argument Pk.
                //   This step can be combined with c
                // c. If kPresent is true, then
                //    i.  Let elementK be the result of calling the Get
                //        internal method of O with the argument ToString(k).
                //   ii.  Let same be the result of applying the
                //        Strict Equality Comparison Algorithm to
                //        searchElement and elementK.
                //  iii.  If same is true, return k.
                if ((k in O) && O[k] === searchElement) {
                    return k;
                }
                k += 1;
            }
            return -1;
        };
    }
    jQuery(document).ready(function ($) {
        "use strict";
        var country_code_to_region_checklist = <?php echo json_encode($country_code_to_region_checklist); ?>, $chosen = $('select.chosenize');
        function updateOptions() {
            var options = this.options, i, length;
            for (i = 0, length = options.length; i < length; i += 1) {
                if (country_code_to_region_checklist.hasOwnProperty(options[i].value)) {
                    if (!options[i].selected) {
                        options[i].setAttribute('disabled', 'disabled');
                    }
                } else {
                    options[i].removeAttribute('disabled');
                }
            }
        }
        $chosen.chosen({ width: "100%" }).each(function () {
            var val = $(this).val() || [];
            $.data(this, 'prev-value', val);
        }).on('change', function () {
            var $this = $(this),
                val = $this.val() || [],
                prev_val = $this.data('prev-value'),
                temp_val,
                k,
                len;
            if (val.length > prev_val.length) {
                for (k = 0, len = val.length; k < len; k += 1) {
                    temp_val = val[k];
                    if (prev_val.indexOf(temp_val) === -1) {
                        country_code_to_region_checklist[temp_val] = this.getAttribute('data-region');
                    }
                }
            } else {
                for (k = 0, len = prev_val.length; k < len; k += 1) {
                    temp_val = prev_val[k];
                    if (val.indexOf(temp_val) === -1) {
                        delete country_code_to_region_checklist[temp_val];
                    }
                }
            }
            $this.data('prev-value', val);
            $chosen.each(updateOptions);
            $chosen.trigger('chosen:updated');
        });
        window.country_code_to_region_checklist = country_code_to_region_checklist;
    });
</script>